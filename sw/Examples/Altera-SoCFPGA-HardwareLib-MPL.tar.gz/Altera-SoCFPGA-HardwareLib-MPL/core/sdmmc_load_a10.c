/******************************************************************************
*
* Copyright 2014 Altera Corporation. All Rights Reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
* 
* 1. Redistributions of source code must retain the above copyright notice,
* this list of conditions and the following disclaimer.
* 
* 2. Redistributions in binary form must reproduce the above copyright notice,
* this list of conditions and the following disclaimer in the documentation
* and/or other materials provided with the distribution.
* 
* 3. Neither the name of the copyright holder nor the names of its contributors
* may be used to endorse or promote products derived from this software without
* specific prior written permission.
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
* ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
* 
******************************************************************************/

/*
 * $Id: //acds/rel/17.1std/embedded/examples/software/Altera-SoCFPGA-HardwareLib-MPL/core/sdmmc_load_a10.c#1 $
 */

// include socal headers
#include <socal/socal.h>
#include "alt_printf.h"
#include "alt_sdmmc.h"
#include "header.h"
#include "mpl_config.h"
#include "mpl_common.h"
#include "sdmmc_common.h"
#include "alt_fpga_manager.h"

// include passdown info for next image location
#include "build.h"

/* Information shared between sdmmc_load_next and sdmmc_load_fpga */
char sdmmc_buf[SDMMC_BLOCK_SZ];
img_header_t * const img_hdr_p = (img_header_t *)sdmmc_buf;

/* Defined in sdmmc_load.c */
extern ALT_SDMMC_CARD_INFO_t card_info;
ALT_STATUS_CODE sdmmc_initialize(void);

#define SDMMC_BLOCK_SZ	512
#define SDMMC_BLK_ALIGN_MSK 0xFFFFFE00

// default value
#ifndef CONFIG_PRELOADER_SDMMC_NEXT_BOOT_IMAGE
#define CONFIG_PRELOADER_SDMMC_NEXT_BOOT_IMAGE (0x440000)
#endif


#define INVALID_BASE_ADDR 0xffffffff
static uint32_t sdmmc_get_sd_base_addr(void)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;
    static uint32_t sd_base_addr = INVALID_BASE_ADDR;
    if(sd_base_addr != INVALID_BASE_ADDR)
    {
        /* This has already been called */
        return sd_base_addr;
    }
    //
    // Initialize SDMMC
    //
    status = sdmmc_initialize();
    if (status != ALT_E_SUCCESS)
    {
        ALT_PRINTF("SDMMC: Error initializing SDMMC.\n");
    }

    MPL_WATCHDOG();

    if (card_info.card_type == ALT_SDMMC_CARD_TYPE_SDHC)
    {
        ALT_PRINTF("SDHC card detected\n");
    }
    else
    {
        ALT_PRINTF("SD card detected\n");
    }

    if (status == ALT_E_SUCCESS)
    {
        // read first block check for MBR Table
        status = alt_sdmmc_read(&card_info, sdmmc_buf, (void *)0, SDMMC_BLOCK_SZ);
        if (status != ALT_E_SUCCESS)
        {
            ALT_PRINTF("SDMMC: Error reading SDMMC.\n");
        }
    }

    //
    // Locate Altera A2 Partition
    //

    if (status == ALT_E_SUCCESS)
    {
        if (alt_read_hword(&sdmmc_buf[MBR_SIG_ADDR]) == MBR_SIGNATURE)
        {
            mbr_partition_entry_t * mbr_entry;
            uint32_t raw = 0;
            
            ALT_PRINTF("SDMMC: Found MBR table\n");
            for (int i = 0; i < 4; i++)
            {
                mbr_entry = (mbr_partition_entry_t*)&sdmmc_buf[(MBR_P1_ADDR + (MBR_PENTRY_SZ * i))];
                if (0xA2 == mbr_entry->p_type)  // 0xA2 is custom-partition type
                {
                    raw++;
                    // get block address and convert to byte address.
                    sd_base_addr = (((mbr_entry->lba_hw2) << 16) | mbr_entry->lba_hw1) * SDMMC_BLOCK_SZ;
                    ALT_PRINTF("SDMMC: Using custom partition %d\n", i);
                }
            }
            if (raw == 0)
            {
                ALT_PRINTF("SDMMC: No custom partition found. Using Raw Mode\n");
                sd_base_addr = 0;
            }
        }
        else
        {
            ALT_PRINTF("SDMMC: No MBR found. Using Raw Mode\n");
            sd_base_addr = 0;
        }
    }
    return sd_base_addr;
}

ALT_STATUS_CODE sdmmc_load(launch_info_t * launch)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;
    uint32_t sd_addr = 0;
    uint32_t* data_src_p;
    uint32_t* data_dst_p;
    uint32_t load_addr, image_size;

    /////
    //
    // Read image header and load image into memory
    //

    if (status == ALT_E_SUCCESS)
    {
        ALT_PRINTF("SDMMC: Start loading Image\n");
        // Read next image header using sd_base_addr found above as the base address
        
        sd_addr = CONFIG_PRELOADER_SDMMC_NEXT_BOOT_IMAGE + sdmmc_get_sd_base_addr();
        status = alt_sdmmc_read(&card_info, sdmmc_buf, (void *)sd_addr, SDMMC_BLOCK_SZ);
        if (status != ALT_E_SUCCESS)
        {
            ALT_PRINTF("SDMMC: Error reading SDMMC.\n");
        }
    }

    if (status == ALT_E_SUCCESS)
    {
        // img_hdr_p always points to sdmmc_buf.
        // img_hdr_p = (img_header_t *)sdmmc_buf;
        
        status = header_validate(img_hdr_p);

        if (status == ALT_E_SUCCESS)
        {
            launch->image_addr = img_hdr_p->load_addr;
            launch->image_size = img_hdr_p->img_size;
#if (CONFIG_PRELOADER_CHECKSUM_NEXT_IMAGE == 1)
            launch->image_crc = img_hdr_p->dcrc;
#endif
            load_addr = img_hdr_p->load_addr;
            image_size= img_hdr_p->img_size;
            launch->entry_addr = load_addr + img_hdr_p->entry_point;
        }
        else
        {
            ALT_PRINTF("SDMMC: Invalid image header.\n");
        }
    }

    if (status == ALT_E_SUCCESS)
    {
        data_src_p = (uint32_t *)&sdmmc_buf[IMG_HDR_SZ];  // Start copying after the image header
        data_dst_p = (uint32_t *)load_addr;
        int loaded_size = SDMMC_BLOCK_SZ - IMG_HDR_SZ;

        while(image_size)
        {
            if(loaded_size > image_size)
                loaded_size = image_size;

            /* Copy the last loaded part to where it belongs */
            for (int i = 0; i < loaded_size; i += sizeof(uint32_t))
            {
                alt_write_word(data_dst_p, alt_read_word(data_src_p));
                data_src_p++; data_dst_p++;
            }
            image_size -= loaded_size;
            sd_addr += SDMMC_BLOCK_SZ;

            if(image_size)
            {
                MPL_WATCHDOG();
                status = alt_sdmmc_read(&card_info, sdmmc_buf, (void *)sd_addr, SDMMC_BLOCK_SZ);
            }

            if (status != ALT_E_SUCCESS)
            {
                ALT_PRINTF("SDMMC: Error reading SDMMC.\n");
                break;
            }
            data_src_p = (uint32_t *)sdmmc_buf;
            loaded_size = SDMMC_BLOCK_SZ;
        }
    }

    MPL_WATCHDOG();

    //
    // Report the entry point and image information
    //

    if (status == ALT_E_SUCCESS)
    {
        ALT_PRINTF("SDMMC: Image loaded successfully.\n");
    }

    //
    // Cleanup SDMMC
    //

    alt_sdmmc_uninit();

    /////

    return status;
}

#ifdef CONFIG_MPL_FPGA_LOAD

typedef struct _sdmmc_user_data
{
    uint64_t sd_addr_copy;
    uint32_t offset, total_loaded;
    uint32_t file_size_copy;
} sdmmc_user_data;

int32_t sdmmc_load_next(void * buf, size_t len, void * user_data)
{
    sdmmc_user_data *p_sdmmc_user_data = (sdmmc_user_data *)user_data;
    uint32_t *sdmmc_buf_copy, *buf_copy, count;
    ALT_STATUS_CODE status = ALT_E_SUCCESS;
    MPL_WATCHDOG();

    if(p_sdmmc_user_data->offset >= SDMMC_BLOCK_SZ)
    {
        /* Need to load more data */
        if(p_sdmmc_user_data->file_size_copy < len + p_sdmmc_user_data->total_loaded)
        {
          len = p_sdmmc_user_data->file_size_copy - p_sdmmc_user_data->total_loaded;
          if(len == 0)
            return 0;/* Were done! */
        }
        status = alt_sdmmc_read(&card_info, buf, (void *)(uint32_t) p_sdmmc_user_data->sd_addr_copy,
            /* Round off to the nearest sdmmc block size */
            (len + SDMMC_BLOCK_SZ - 1) & SDMMC_BLK_ALIGN_MSK);
        if(status != ALT_E_SUCCESS)
          return 0;
        p_sdmmc_user_data->total_loaded += len;
        p_sdmmc_user_data->sd_addr_copy += len;
        if(status != ALT_E_SUCCESS)
            len = 0;
    }
    else
    {
        if(len > SDMMC_BLOCK_SZ - p_sdmmc_user_data->offset)
            len = SDMMC_BLOCK_SZ - p_sdmmc_user_data->offset;

        /*memcpy(buf, sdmmc_buf_copy + p_sdmmc_user_data->offset, len);*/
        sdmmc_buf_copy = (uint32_t *)(sdmmc_buf + p_sdmmc_user_data->offset);
        buf_copy = (uint32_t *) buf;
        for(count = 0; count < len; count+=4)
            *(buf_copy++) = *(sdmmc_buf_copy++);
        p_sdmmc_user_data->offset += len;
    }
    MPL_WATCHDOG();
    return len;
}

ALT_STATUS_CODE sdmmc_load_fpga()
{
    sdmmc_user_data user_data;
    ALT_STATUS_CODE status = ALT_E_SUCCESS;
    uint32_t sd_addr = CONFIG_PRELOADER_FPGA_IMAGE_SDMMC_ADDR + sdmmc_get_sd_base_addr();

    //
    // Initialize SDMMC
    //
    status = sdmmc_initialize();
    if (status != ALT_E_SUCCESS)
    {
        ALT_PRINTF("SDMMC: Error initializing SDMMC.\n");
    }

    MPL_WATCHDOG();

    //
    // Read FPGA header and load FPGA into memory
    //

    if (status == ALT_E_SUCCESS)
    {
        // Read the FPGA image header using sd_base_addr found above as the base address
        status = alt_sdmmc_read(&card_info, sdmmc_buf, (void *)(uint32_t) sd_addr, SDMMC_BLOCK_SZ);
        if (status != ALT_E_SUCCESS)
        {
            ALT_PRINTF("SDMMC: Error reading SDMMC.\n");
        }
    }

    if (status == ALT_E_SUCCESS)
    {
        // img_hdr_p always points to sdmmc_buf.
        status = header_validate(img_hdr_p);

        if (status != ALT_E_SUCCESS)
        {
            ALT_PRINTF("SDMMC: Invalid FPGA header.\n");
        }
    }
    user_data.file_size_copy = img_hdr_p->img_size;
    user_data.sd_addr_copy = sd_addr + SDMMC_BLOCK_SZ;
    user_data.offset = IMG_HDR_SZ;
    user_data.total_loaded = SDMMC_BLOCK_SZ;

/* Time to start the fpga */
    if (status == ALT_E_SUCCESS)
    {
        status = alt_fpga_init();
    }

    MPL_WATCHDOG();

    // Take control of the FPGA CB
    if (status == ALT_E_SUCCESS)
    {
        status = alt_fpga_control_enable(ALT_FPGA_CFG_MODE_PP32_FAST_NOAES_DC);
    }

    MPL_WATCHDOG();

    if (status == ALT_E_SUCCESS)
    {
        status = alt_fpga_istream_configure(sdmmc_load_next, &user_data);
    }

    MPL_WATCHDOG();

    /////

    return status;
}

#endif

