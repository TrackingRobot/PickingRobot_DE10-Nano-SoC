/******************************************************************************
*
* Copyright 2014 Altera Corporation. All Rights Reserved.
* 
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
* 
* 1. Redistributions of source code must retain the above copyright notice,
* this list of conditions and the following disclaimer.
* 
* 2. Redistributions in binary form must reproduce the above copyright notice,
* this list of conditions and the following disclaimer in the documentation
* and/or other materials provided with the distribution.
* 
* 3. Neither the name of the copyright holder nor the names of its contributors
* may be used to endorse or promote products derived from this software without
* specific prior written permission.
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
* ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
* 
******************************************************************************/

/*
 * $Id: //acds/rel/17.1std/embedded/examples/software/Altera-SoCFPGA-HardwareLib-SPI-CV-GNU/hwlib.c#1 $
 */

/* Test run for SPI EEPROM M95256 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include "alt_spi.h"
#include "alt_printf.h"

#if defined(__ARMCC_VERSION) && defined(PRINTF_UART)
#pragma import(__use_no_semihosting)
void _sys_exit(int return_code)
{
    while(1);
}
#endif

/*
 * !!!
 * When accessing EEPROM device, note:
 *
 * If user wishes to keep the slave select signal remains active for the duration of the serial transfer,
 * set both serial clock phase(SCPH) and the serial clock polarity(SCPOL) configuration parameters
 * to logic 1;
 *
 * The above guideline is implemented as such.
 * !!!
 * */

#ifndef ARRAY_COUNT
#define ARRAY_COUNT(array) (sizeof(array) / sizeof(array[0]))
#endif

#ifndef MIN
#define MIN(a, b) ((a) > (b) ? (b) : (a))
#endif

#define SPI_EEPROM_TIMEOUT_ACK              200000

#define SPI_EEPROM_BLOCK_DATA               4

#define SPI_EEPROM_SINGLE_BLOCK             64
#define SPI_EEPROM_CTRL_DATA_SIZE           3
#define SPI_EEPROM_ADDRESS_MAX              0xFFF

void get_error_type(ALT_STATUS_CODE cause, char * output, size_t size)
{
    char * name;
    char buffer[32];

    switch (cause)
    {
    case ALT_E_ERROR:
        name = "ERROR";
        break;
    case ALT_E_SUCCESS:
        name = "SUCCESS";
        break;
    case ALT_E_BAD_ARG:
        name = "BAD_ARG";
        break;
    case ALT_E_ARG_RANGE:
        name = "ARG_RANGE";
        break;
    case ALT_E_TMO:
        name = "TMO";
        break;
    default:
        snprintf(buffer, sizeof(buffer), "UNKNOWN[0x%" PRIx32 "]", cause);
        name = buffer;
        break;
    }

    snprintf(output, size, "ALT_E_%s", name);
}

/*
 * Function set write enable to eeprom
*/
ALT_STATUS_CODE test_spi_eeprom_wr_enable(ALT_SPI_DEV_t *device)
{
    uint16_t send_buffer[] = { 0x06 };

    return alt_spi_master_tx_transfer(device, 0x1, ARRAY_COUNT(send_buffer), send_buffer);
}

/*
 * Function readwrite data from eeprom
*/
ALT_STATUS_CODE test_spi_eeprom_read_status(ALT_SPI_DEV_t * device,
                                            uint8_t * eeprom_status)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;

    uint16_t send_buffer[] = { 0x05, 0x0 };
    uint16_t recv_buffer[ARRAY_COUNT(send_buffer)];

    status = alt_spi_master_tx_rx_transfer(device, 0x1, ARRAY_COUNT(send_buffer), send_buffer, recv_buffer);
    if (status == ALT_E_SUCCESS)
    {
        *eeprom_status = recv_buffer[1];
    }

    return status;
}

/*
 * Function wait while eeprom will ready to answer
*/
ALT_STATUS_CODE test_spi_eeprom_wait_for_ready(ALT_SPI_DEV_t * device)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;

    uint8_t eeprom_status;
    uint32_t timeout = SPI_EEPROM_TIMEOUT_ACK;
    do
    {
        status = test_spi_eeprom_read_status(device, &eeprom_status);
        if (status != ALT_E_SUCCESS)
        {
            break;
        }

        if (--timeout == 0)
        {
            status = ALT_E_TMO;
            break;
        }
    }
    while (eeprom_status & 0x1);

    return status;
}

/*
 * Function wait while spi bus is busy
*/
ALT_STATUS_CODE alt_spi_wait_for_idle(ALT_SPI_DEV_t *device)
{
    uint32_t timeout = SPI_EEPROM_TIMEOUT_ACK;

    do
    {
        if (--timeout == 0)
        {
            return ALT_E_TMO;
        }
    }
    while (alt_spi_is_busy(device));

    return ALT_E_SUCCESS;
}

/*
 * Configuration of the spi controler
*/
ALT_STATUS_CODE test_spi_setup(ALT_SPI_CTLR_t ctlr, ALT_SPI_DEV_t * device, uint32_t speed)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;
    ALT_SPI_CONFIG_t cfg;

    ALT_PRINTF("INFO: Setup SPI.\n");

    if (status == ALT_E_SUCCESS)
    {
        status = alt_spi_init(ctlr, device);
        if (status != ALT_E_SUCCESS)
        {
            char buffer[64];
            get_error_type(status, buffer, sizeof(buffer));
            ALT_PRINTF("ERROR: alt_spi_init() failed; status = [%s].\n", buffer);
        }
    }

    if (status == ALT_E_SUCCESS)
    {
        cfg.frame_size    = ALT_SPI_DFS_8BIT;
        cfg.frame_format  = ALT_SPI_FRF_SPI;
        cfg.clk_phase     = ALT_SPI_SCPH_TOGGLE_START;
        cfg.clk_polarity  = ALT_SPI_SCPOL_INACTIVE_HIGH;
        cfg.loopback_mode = 0;
        cfg.transfer_mode = ALT_SPI_TMOD_TXRX;

        status = alt_spi_config_set(device, &cfg);
    }

    if (status == ALT_E_SUCCESS)
    {
        /* status = alt_spi_rx_sample_delay_set(device, 16); */
    }

    if (status == ALT_E_SUCCESS)
    {
        ALT_PRINTF("INFO: Set speed: %" PRIu32 "Hz\n", speed);
        status = alt_spi_speed_set(device, speed);
    }

    if (status == ALT_E_SUCCESS)
    {
        uint32_t out_speed;
        status = alt_spi_speed_get(device, &out_speed);

        if (status == ALT_E_SUCCESS)
        {
            ALT_PRINTF("INFO: Get speed: %" PRIu32 "Hz\n", out_speed);
        }
    }

    if (status == ALT_E_SUCCESS)
    {
        status = alt_spi_enable(device);
    }

    if (status == ALT_E_SUCCESS)
    {
        status = alt_spi_wait_for_idle(device);
    }

    return status;
}

void test_spi_cleanup(ALT_SPI_DEV_t * device)
{
    if (alt_spi_disable(device) != ALT_E_SUCCESS)
    {
        ALT_PRINTF("WARN: alt_spi_disable() failed.\n");
    }

    if (alt_spi_uninit(device) != ALT_E_SUCCESS)
    {
        ALT_PRINTF("WARN: alt_spi_uninit() failed.\n");
    }
}

/*
 * Function readwrite data from eeprom
*/
ALT_STATUS_CODE test_spi_eeprom_rw_data(ALT_SPI_DEV_t * device,
                                        uint16_t * test_data_w,
                                        uint16_t * test_data_r,
                                        uint16_t address,
                                        size_t data_size)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;

    uint16_t test_data_temp_w[SPI_EEPROM_SINGLE_BLOCK + SPI_EEPROM_CTRL_DATA_SIZE];
    uint16_t test_data_temp_r[SPI_EEPROM_SINGLE_BLOCK];

    uint32_t mem_offset = 0;
    uint32_t left_size = data_size;
    uint32_t send_size;

    while (left_size)
    {
        if (status != ALT_E_SUCCESS)
        {
            break;
        }

        if (status == ALT_E_SUCCESS)
        {
            status = alt_spi_wait_for_idle(device);
        }
        if (status == ALT_E_SUCCESS)
        {
            status = test_spi_eeprom_wait_for_ready(device);
        }
        if (status == ALT_E_SUCCESS)
        {
            status = test_spi_eeprom_wr_enable(device);
        }

        test_data_temp_w[0] = 0x2;
        test_data_temp_w[1] = ((address + mem_offset) & 0xFF00) >> 8;
        test_data_temp_w[2] = ((address + mem_offset) & 0x00FF) >> 0;

        send_size = MIN(SPI_EEPROM_SINGLE_BLOCK, left_size);
        memcpy(test_data_temp_w + SPI_EEPROM_CTRL_DATA_SIZE, test_data_w + mem_offset, send_size * sizeof(uint16_t));

        if (status == ALT_E_SUCCESS)
        {
            status = alt_spi_master_tx_transfer(device, 0x1, send_size + SPI_EEPROM_CTRL_DATA_SIZE, test_data_temp_w);
        }
        if (status == ALT_E_SUCCESS)
        {
            status = alt_spi_wait_for_idle(device);
        }
        if (status == ALT_E_SUCCESS)
        {
            status = test_spi_eeprom_wait_for_ready(device);
        }
        if (status == ALT_E_SUCCESS)
        {
            status = alt_spi_wait_for_idle(device);
        }
        if (status == ALT_E_SUCCESS)
        {
            status = alt_spi_master_eeprom_transfer(device, 0x1, 0x3, address + mem_offset,
                                                    send_size, test_data_temp_r);
        }

        if (status == ALT_E_SUCCESS)
        {
            memcpy(test_data_r + mem_offset, test_data_temp_r, send_size * sizeof(uint16_t));

            mem_offset += send_size;
            left_size  -= send_size;
        }
    }

    return status;
}

/*
 * This is ping pong test for eeprom
*/
ALT_STATUS_CODE test_spi_eeprom_rw(ALT_SPI_CTLR_t ctlr, uint32_t speed)
{
    ALT_SPI_DEV_t _device;
    ALT_SPI_DEV_t * device = &_device;
    ALT_STATUS_CODE status = ALT_E_SUCCESS;

    uint16_t test_data_s[SPI_EEPROM_BLOCK_DATA];
    uint16_t test_data_r[SPI_EEPROM_BLOCK_DATA];
    uint32_t i;

    ALT_PRINTF("TEST: Common EEPROM Test (speed %" PRIu32 "Hz, all else default).\n",
               speed);

    if (status == ALT_E_SUCCESS)
    {
        status = test_spi_setup(ctlr, device, speed);
    }

    /*
     * Prepare random data for sending to eeprom
    */
    if (status == ALT_E_SUCCESS)
    {
        for (i = 0; i < SPI_EEPROM_BLOCK_DATA; i++)
        {
            test_data_s[i] = rand() & 0xFF;
            test_data_r[i] = 0;
        }
    }

    if (status == ALT_E_SUCCESS)
    {
        uint16_t address = 0;
        address = rand() & SPI_EEPROM_ADDRESS_MAX;
        address -= address % SPI_EEPROM_SINGLE_BLOCK;

        ALT_PRINTF("INFO: Address = 0x%x.\n", address);

        status = test_spi_eeprom_rw_data(device, test_data_s, test_data_r, address, SPI_EEPROM_BLOCK_DATA);
        if (status != ALT_E_SUCCESS)
        {
            char buffer[64];
            get_error_type(status, buffer, sizeof(buffer));
            printf("ERROR: During write data [%s].\n", buffer);
        }
    }

    /*
     * Compare data in send and receive arrays.
    */
    if (status == ALT_E_SUCCESS)
    {
        ALT_PRINTF("TEST Write data :");
        for (i = 0; i < SPI_EEPROM_BLOCK_DATA; i++)
        {
            ALT_PRINTF(" 0x%x", test_data_s[i]);
        }
        ALT_PRINTF(".\n");

        ALT_PRINTF("TEST Read data  :");
        for (i = 0; i < SPI_EEPROM_BLOCK_DATA; i++)
        {
            ALT_PRINTF(" 0x%x", test_data_r[i]);
        }
        ALT_PRINTF(".\n");

        for (i = 0; i < SPI_EEPROM_BLOCK_DATA; i++)
        {
            if (test_data_s[i] != test_data_r[i])
            {
                ALT_PRINTF("INFO: Mismatch found at index 0x%x.\n", (unsigned int) i);
                status = ALT_E_ERROR;
            }
        }
    }

    test_spi_cleanup(device);

    if (status == ALT_E_SUCCESS)
    {
        ALT_PRINTF("RESULT: OK!.\n\n");
    }
    else
    {
        ALT_PRINTF("RESULT: Something went wrong :(.\n\n");
    }

    return status;
}

int main(int argc, char** argv)
{
    ALT_STATUS_CODE status = ALT_E_SUCCESS;
#if defined(__ARMCC_VERSION) && defined(PRINTF_UART)
/* Without Semihosting we don't have an argc/argv. Attempting to use them causes linker errors */
    int argc_=0; char **argv_=NULL;
  #define argc argc_
  #define argv argv_
#endif
    /*
     * Extract the random seed from arguments.
    */
    if (argc < 2)
    {
        ALT_PRINTF("ERROR: No random integer given on command line.\n");
        status = ALT_E_ERROR;
    }

    if (status == ALT_E_SUCCESS)
    {
        char * endptr = NULL;
        int randint = strtol(argv[1], &endptr, 0);

        if (endptr == argv[1])
        {
            ALT_PRINTF("ERROR: strtol() unable to parse [%s].\n", argv[1]);
            status = ALT_E_ERROR;
        }
        else
        {
            ALT_PRINTF("INFO: Pseudo random integer seed = %d.\n", randint);
            srand(randint);
        }
    }

    if (status == ALT_E_SUCCESS)
    {
        status = test_spi_eeprom_rw(ALT_SPI_SPIM0, 2000000);
    }

    if (status == ALT_E_SUCCESS)
    {
        ALT_PRINTF("RESULT: Example completed successfully.\n");
        return 0;
    }
    else
    {
        ALT_PRINTF("RESULT: Some failures detected.\n");
        return 1;
    }
}

/* enable semihosting with gcc by defining an __auto_semihosting symbol */
#if !defined(__ARMCC_VERSION) && !defined(PRINTF_UART)
int __auto_semihosting;
#endif
