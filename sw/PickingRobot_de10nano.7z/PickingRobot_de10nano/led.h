#ifndef __LED_H
#define __LED_H


#include "driverInit.h"
#include "motor.h"
#include "inputdetect.h"

int led();

#endif